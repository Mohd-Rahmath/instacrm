const { Sequelize } = require('sequelize');
const fs = require('fs');
const path = require('path');
const rootPath = path.dirname(require.main.filename);
const modelDirectoryPath = path.join(rootPath,'src/apis/v1/model');




const basename = path.basename(__filename);
// eslint-disable-next-line import/no-dynamic-require
const db = {};

const sequelize = new Sequelize('instacrm', 'cr_api_user', 'jw8s0F4', {
  host: 'localhost',
  dialect: 'postgres',
  logging: console.log,
});

const connect = async () => {
  return new Sequelize('instacrm', 'cr_api_user', 'jw8s0F4', {
    host: 'localhost',
    dialect: 'postgres',
    logging: console.log,
  })
    .authenticate()
    .then(() => {
      // eslint-disable-next-line no-console
      console.log('Connection has been established successfully to postgres.');
    })
    .catch(err => {
      // eslint-disable-next-line no-console
      console.error('Unable to connect to the database:', err);
    });
};

fs.readdirSync(modelDirectoryPath)
  .filter(file => {
    return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
  })
  .forEach(file => {
    const model = require(path.join(modelDirectoryPath, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });


Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});


db.sequelize = sequelize;
module.exports = {
  db,
  connect,
};

