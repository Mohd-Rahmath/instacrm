const express = require('express')
const jwt = require('jsonwebtoken');
const app = express();
const bodyParser = require('body-parser')
const authorization = require('./authorization-middleware');
const pgsqlDb = require('./config/database');
const cors = require('cors');
const router = express.Router();


//router controllers
// var register = require('./src/apis/v1/auth/routes/register');

var register = require('./src/apis/v1/auth/controllers/register');

app.use(cors());

app.use(logger);

// create application/json parser
const jsonParser = bodyParser.json()

app.get('/token', (req, res) => {
    const payload = {
        name: 'rahmath',
        scopes: ["customer:create", "auth:api"]
    };
    const token = jwt.sign(payload, '123456');
    res.send(token);
});

app.get('/', authorization('auth:api'), function (req, res) {
    res.send('Hello World!')
});

app.get('/users', function (req, res) {
    res.send('Hello World!')
})

function logger(req, res, next) {
    console.log('LOGGED')
    next()
}

app.use('/api',register);



app.listen(3000)



