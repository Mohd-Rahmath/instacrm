module.exports = {
    JWT_SECRET: "123456"
  };