const express = require('express')
const bodyParser = require('body-parser')
const pgsqlDb = require('../../../../../config/database');
const router = express.Router()
const boom = require('@hapi/boom');
const bcrypt = require('bcrypt');


// create application/json parser
const jsonParser = bodyParser.json()

router.post('/instacrm/register', jsonParser, async (req, res) => {
	try {
		console.log('req',req.body.email);
		if (
			await pgsqlDb.db.users.findOne({
				where: {
					email: req.body.email,
				},
			})
		) {
			res.json({statusOk:false,message:'email already exists'});
		}
		let password;
		if(req.body.password){
			const salt = await bcrypt.genSaltSync(10, 'a');
			 password = bcrypt.hashSync(req.body.password, salt);
		}
		const userData = await pgsqlDb.db.users.create({
			name: req.body.name,
			email: req.body.email,
			password: password
		});
		res.json(userData);

	} catch (err) {
		res.json(err);
	}
})

module.exports = router
