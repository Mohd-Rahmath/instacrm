// import express from 'express';
// import { celebrate, Joi } from 'celebrate';
const express = require('express');
// import register from '../controllers/register';
const register = require('../controllers/register');

const router = express.Router();

// const userSchema = {
//   body: Joi.object({
//     phone_number: Joi.string().required(),
//   }),
// };

/**
 * @swagger
 * definitions:
 *  Register:
 *    type: object
 *    required:
 *       - phone_number
 *    properties:
 *       phone_number:
 *         type: string
 *
 * /register:
 *   post:
 *     tags:
 *      - Auth
 *     description: Register user
 *     produces:
 *       - application/json
 *     consumes:
 *       - "application/json"
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         description: "Phone Number"
 *         required: true
 *         schema:
 *           $ref: "#/definitions/Register"
 *     responses:
 *       200:
 *         description: A JSON object containing message.
 *         schema:
 *            type: object
 *            properties:
 *              message:
 *               type: string
 *
 */
router.post(`/register`, register);

// export default router;